function calculateFee(){

const fee = document.getElementById("fee").value;
const discount = document.getElementById("discount").value;

const finalFee = fee - (fee * discount / 100);

document.getElementById("finalFee").value = finalFee;

}