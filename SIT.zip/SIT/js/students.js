function generateStudentId(){

return "SIT-" + Date.now();

}

// Add Student
function addStudent(){

const name = document.getElementById("name").value;
const course = document.getElementById("course").value;
const fee = document.getElementById("fee").value;

const student = {

studentId: generateStudentId(),
name:name,
course:course,
fee:fee

};

const tx = db.transaction(["students"],"readwrite");

const store = tx.objectStore("students");

store.add(student);

alert("Student Added");

}

// Load Student

function loadStudents(){

const tx = db.transaction(["students"],"readonly");

const store = tx.objectStore("students");

const request = store.getAll();

request.onsuccess = function(){

const data = request.result;

let table="";

data.forEach(function(student){

table+=`
<tr>
<td>${student.studentId}</td>
<td>${student.name}</td>
<td>${student.course}</td>
<td>${student.fee}</td>
</tr>
`;

});

document.getElementById("studentsTable").innerHTML=table;

};

}

let selectedPhoto = null;

// Photo Upload Handler
function handlePhotoUpload(event){
    const file = event.target.files[0];
    if(file){
        const reader = new FileReader();
        reader.onload = function(e){
            selectedPhoto = e.target.result; // base64 string
        };
        reader.readAsDataURL(file);
    }
}

// Add Student + Generate Admission Form
function addStudentAndGenerateForm(){

    const name = document.getElementById("name").value;
    const fatherName = document.getElementById("fatherName").value;
    const phone = document.getElementById("phone").value;
    const address = document.getElementById("address").value;
    const course = document.getElementById("course").value;
    const fee = parseFloat(document.getElementById("fee").value);
    const discount = parseFloat(document.getElementById("discount").value);
    const finalFee = fee - (fee * discount / 100);
    const studentId = "SIT-" + Date.now();
    const admissionDate = new Date().toLocaleDateString();

    const student = {
        studentId,
        name,
        fatherName,
        phone,
        address,
        course,
        fee,
        discount,
        finalFee,
        photo: selectedPhoto,
        admissionDate
    };

    // Save to IndexedDB
    const tx = db.transaction(["students"],"readwrite");
    const store = tx.objectStore("students");
    store.add(student);
    tx.oncomplete = function(){
        alert("Student Added Successfully");
        generateAdmissionForm(student);
    };
}

// Generate Admission Form HTML
function generateAdmissionForm(student){
    const formWindow = window.open("","Admission Form","width=800,height=600");
    formWindow.document.write(`
        <html>
        <head>
            <title>Admission Form</title>
            <style>
                body{font-family:Arial; padding:20px;}
                .photo{float:right; width:120px;}
                table{width:100%; border-collapse: collapse;}
                td{padding:8px; border:1px solid #ddd;}
                h1,h3{text-align:center;}
                button{margin-top:20px; padding:10px 15px; background:#2c7be5; color:white; border:none; cursor:pointer;}
            </style>
        </head>
        <body>
            <h1>Skillzhub Institute of Technology (SIT)</h1>
            <h3>Admission Form</h3>
            ${student.photo ? `<img src="${student.photo}" class="photo">` : ''}
            <table>
                <tr><td>Student ID</td><td>${student.studentId}</td></tr>
                <tr><td>Name</td><td>${student.name}</td></tr>
                <tr><td>Father Name</td><td>${student.fatherName}</td></tr>
                <tr><td>Phone</td><td>${student.phone}</td></tr>
                <tr><td>Address</td><td>${student.address}</td></tr>
                <tr><td>Course</td><td>${student.course}</td></tr>
                <tr><td>Admission Date</td><td>${student.admissionDate}</td></tr>
                <tr><td>Course Fee</td><td>${student.fee}</td></tr>
                <tr><td>Discount</td><td>${student.discount}%</td></tr>
                <tr><td>Final Fee</td><td>${student.finalFee}</td></tr>
            </table>
            <button onclick="window.print()">Print</button>
        </body>
        </html>
    `);
}