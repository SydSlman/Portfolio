const dbName = "SITAcademyDB";
let db;

const request = indexedDB.open(dbName, 1);

request.onupgradeneeded = function(event){

db = event.target.result;

if(!db.objectStoreNames.contains("students")){

const store = db.createObjectStore("students",{keyPath:"studentId"});

store.createIndex("name","name",{unique:false});
store.createIndex("course","course",{unique:false});

}

if(!db.objectStoreNames.contains("users")){

db.createObjectStore("users",{keyPath:"userId",autoIncrement:true});

}

};

request.onsuccess = function(event){

db = event.target.result;
console.log("Database Ready");

};